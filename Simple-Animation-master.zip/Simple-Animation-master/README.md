# XOR PROBLEMİ
xor probleminin çözümü
